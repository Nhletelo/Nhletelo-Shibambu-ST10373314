﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace RecipeProgram
{
    // Create a class to stand in for an ingredient.
    public class Ingredient
    {
        // Characteristics to record an ingredient's name, amount, starting amount, and unit
        public string Name { get; set; } // The ingredient's name is stored in this attribute.
        public double InitialQuantity { get; set; } // The ingredient's initial quantity is stored in this attribute.
        public double Quantity { get; set; } // The ingredient's quantity is stored in this attribute.
        public string Unit { get; set; } // The ingredient's measurement unit is stored in this property.
        public double Calories { get; set; } // The number of calories in the ingredient.
        public string FoodGroup { get; set; } // The food group that the ingredient belongs to.

        // Use the constructor to initialize an ingredient with a name, quantity, unit, calories, and food group.
        public Ingredient(string name, double quantity, string unit, double calories, string foodGroup)
        {
            Name = name; // The name property should be initialized using the specified name.
            Quantity = quantity; // Set the quantity property's initial value to the given amount.
            InitialQuantity = quantity; // Use the supplied quantity to initialize the initial quantity property.
            Unit = unit; // Set the unit property's initial value to the supplied unit.
            Calories = calories; // Set the calories property to the provided value.
            FoodGroup = foodGroup; // Set the food group property to the provided value.
        }

        // Modify the ToString function to show a component in a legible manner
        public override string ToString()
        {
            return $"{Quantity} {Unit} of {Name}"; // Provide back the ingredient as a string in the format "quantity unit of name".
        }
    }

    // Creating a class that represents a recipe.
    class Recipe
    {
        // Properties to store the name, ingredients, and steps of a recipe
        public string Name { get; set; } // This property holds the name of the recipe.
        public List<Ingredient> Ingredients { get; set; } // This property holds a list of ingredients for the recipe.
        public string[] Steps { get; set; } // This property holds an array of steps for the recipe.

        // Constructor to initialize a recipe with a name, number of ingredients, and number of steps
        public Recipe(string name, int ingredientCount, int stepCount)
        {
            Name = name; // Initialize the name property with the provided name.
            Ingredients = new List<Ingredient>(ingredientCount); // Create a new list of ingredients with the provided ingredient count.
            Steps = new string[stepCount]; // Create a new array of steps with the provided step count.
        }

        // Method to add an ingredient to the recipe
        public void AddIngredient(Ingredient ingredient)
        {
            Ingredients.Add(ingredient); // Add the provided ingredient to the ingredients list.
        }

        // Method to add a step to the recipe at a specific index
        public void AddStep(int index, string step)
        {
            Steps[index] = step; // Add the provided step to the steps array at the specified index.
        }

        // Way to present the recipe to the user
        public void DisplayRecipe()
        {
            // Show the name of the recipe
            Console.WriteLine($"**Recipe: {Name}**");

            // Show the list of ingredients
            Console.WriteLine("Ingredients:");
            foreach (Ingredient ingredient in Ingredients)
            {
                Console.WriteLine($"- {ingredient}"); // Use the format "quantity unit of name" to display each ingredient.
            }

            // Display the list of steps
            Console.WriteLine("Steps:");
            for (int i = 0; i < Steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i]}"); // Show the number that corresponds to each step.
            }
        }

        // How to scale the recipe according to a specified factor
        public void ScaleRecipe(double factor)
        {
            // Verify the validity of the factor
            if (factor <= 0)
            {
                Console.WriteLine("Invalid scaling factor. Please enter a positive number.");
                return;
            }

            // Adjust each ingredient's quantity by the scaling factor.
            foreach (Ingredient ingredient in Ingredients)
            {
                ingredient.Quantity *= factor; // Adjust each ingredient's amount based on the given factor.
            }

            Console.WriteLine($"Recipe scaled by a factor of {factor}.");
        }

        // A procedure to return all ingredient quantities to their initial, non-negative values
        // Code for resetting ingredient quantities in a recipe.
        public void ResetQuantities()
        {
            // Verify that the quantity of each ingredient is non-negative.
            foreach (Ingredient ingredient in Ingredients)
            {
                ingredient.Quantity = Math.Max(ingredient.InitialQuantity, 0); // Ensure that the quantity of each ingredient is non-negative.
            }
            Console.WriteLine("Ingredient quantities reset to their original non-negative values.");
        }

        // Method to calculate the total calories of all ingredients in the recipe
        public double CalculateTotalCalories()
        {
            double totalCalories = 0;
            foreach (Ingredient ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories * ingredient.Quantity;
            }
            return totalCalories;
        }
    }

    // Main program class
    class Program
    {
        // A list of permitted units that is predefined and includes shortcuts and complete names
        static string[] allowedUnits = { "grams", "g", "kilograms", "kg", "ounces", "oz", "cups", "cup", "liters", "L", "teaspoons", "tsp", "tablespoons", "tbsp", "tablespoon" };

        // The Main method
        static void Main(string[] args)
        {
            List<Recipe> recipes = new List<Recipe>(); // Create a list to store multiple recipes.

            // Show the welcome message
            Console.WriteLine("\nWelcome to our Recipe App!");

            // Repeat to show the menu and process user input
            while (true)
            {
                // Display the menu items.
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Create Recipe");
                Console.WriteLine("2. Display Recipes");
                Console.WriteLine("3. Scale Recipe");
                Console.WriteLine("4. Reset Quantities");
                Console.WriteLine("5. Clear Recipe");
                Console.WriteLine("6. Exit");
                Console.WriteLine("7. Display Specific Recipe"); // New option
                Console.Write("Enter your choice: ");

                // Check the user's choice
                int choice;
                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Invalid choice. Please enter a number between 1 and 7.");
                    continue;
                }

                // Take actions in accordance with the user's selection
                switch (choice)
                {
                    case 1: // Create a new recipe
                        Recipe newRecipe = CreateRecipe();
                        if (newRecipe != null)
                        {
                            recipes.Add(newRecipe);// Add the new recipe to the list of recipes
                        }
                        break;
                    case 2: // Display all recipes
                        if (recipes.Count == 0)
                        {
                            Console.WriteLine("No recipes created yet.");
                        }
                        else
                        {
                            // Create a list to store recipe names
                            List<string> recipeNames = new List<string>();

                            // Add all recipe names to the list
                            foreach (Recipe recipe in recipes)
                            {
                                recipeNames.Add(recipe.Name);
                            }

                            // Sort the recipe names alphabetically
                            recipeNames.Sort();

                            // Display the sorted recipe names
                            Console.WriteLine("Recipes:");
                            foreach (string recipeName in recipeNames)
                            {
                                Console.WriteLine($"- {recipeName}");
                            }
                        }
                        break;
                    case 3: // Scale a recipe
                        ScaleRecipe(recipes);
                        break;
                    case 4: // Reset ingredient quantities
                        ResetQuantities(recipes);
                        break;
                    case 5: // Delete a recipe
                        ClearRecipe(recipes);
                        break;
                    case 6: // Close the application
                        Console.WriteLine("Goodbye!");
                        return;
                    case 7: // Display a specific recipe
                        DisplaySpecificRecipe(recipes);
                        break;
                    default: // Deal with incorrect selections
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 7.");
                        break;
                }
            }
        }

        // Method to create a new recipe based on user input
        static Recipe CreateRecipe()
        {
            // Request information from the user for the new recipe.
            string name;
            do
            {
                Console.Write("Enter recipe name: ");
                name = Console.ReadLine();// Get and trim the recipe name

                if (string.IsNullOrWhiteSpace(name))
                {
                    Console.WriteLine("Recipe name cannot be empty. Please enter a valid name.");
                }
                else if (ContainsNumbers(name))
                {
                    Console.WriteLine("Invalid recipe name. Please enter a valid name containing only letters.");
                    name = null; // Resetting the name to null will repeat the loop.
                }

            } while (string.IsNullOrWhiteSpace(name));

            // Examine and confirm the ingredient count.
            int ingredientCount;
            do
            {
                Console.Write("Enter number of ingredients: ");
                string input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Number of ingredients cannot be empty. Please enter a valid positive integer.");
                    continue;
                }

                if (!int.TryParse(input, out ingredientCount) || ingredientCount <= 0)
                {
                    Console.WriteLine("Invalid number of ingredients. Please enter a valid positive integer.");
                    continue;
                }

                break; // If the input is valid, end the loop.
            } while (true);

            // Only move forward if the ingredient count is accurate.
            if (ingredientCount <= 0)
            {
                return null;
            }

            //Examine and confirm how many steps there are.
            int stepCount;
            do
            {
                Console.Write("Enter number of steps: ");
                string input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Number of steps cannot be empty. Please enter a valid positive integer.");
                    continue;
                }

                if (!int.TryParse(input, out stepCount) || stepCount <= 0)
                {
                    Console.WriteLine("Invalid number of steps. Please enter a valid positive integer.");
                    continue;
                }

                break; // If the input is correct, end the loop.
            } while (true);

            // Construct a new recipe object using the supplied information.
            Recipe recipe = new Recipe(name, ingredientCount, stepCount);

            // Request information from the user for every ingredient.
            for (int i = 0; i < ingredientCount; i++)
            {
                string ingredientName;
                do
                {
                    Console.Write($"Enter name of ingredient {i + 1}: ");
                    ingredientName = Console.ReadLine();
                    if (string.IsNullOrWhiteSpace(ingredientName) || double.TryParse(ingredientName, out _))
                    {
                        Console.WriteLine("Invalid ingredient name. Please enter a valid name.");
                    }
                    else
                    {
                        break; // End the loop in the event that the input is valid
                    }
                } while (true);

                double quantity;
                bool validQuantity = false;
                do
                {
                    Console.Write($"Enter quantity of {ingredientName}: ");
                    string quantityInput = Console.ReadLine();

                    if (!double.TryParse(quantityInput, out quantity) || quantity <= 0)
                    {
                        Console.WriteLine("Invalid quantity. Please enter a valid positive number.");
                    }
                    else
                    {
                        validQuantity = true;
                    }
                } while (!validQuantity);

                string unit;
                bool validUnit = false;
                do
                {
                    Console.Write($"Enter unit of {ingredientName}: ");
                    unit = Console.ReadLine();

                    // Verify that the unit you typed is in the list of permitted units.
                    if (!IsUnitAllowed(unit))
                    {
                        Console.WriteLine("Invalid unit. Please enter one of the following units: grams, kilograms, ounces, cups, liters, teaspoons, tablespoons");
                    }
                    else
                    {
                        validUnit = true;
                    }
                } while (!validUnit);

                double calories;
                bool validCalories = false;
                do
                {
                    Console.Write($"Enter calories for {ingredientName}: ");
                    string caloriesInput = Console.ReadLine();

                    if (!double.TryParse(caloriesInput, out calories) || calories <= 0)
                    {
                        Console.WriteLine("Invalid calories. Please enter a valid positive number.");
                    }
                    else
                    {
                        validCalories = true;
                    }
                } while (!validCalories);

                string foodGroup;
                do
                {
                    Console.Write($"Enter food group for {ingredientName}: ");
                    foodGroup = Console.ReadLine();
                } while (string.IsNullOrWhiteSpace(foodGroup));

                // Using the provided information, create a new ingredient object and add it to the recipe.
                Ingredient ingredient = new Ingredient(ingredientName, quantity, unit, calories, foodGroup);
                recipe.AddIngredient(ingredient);
            }

            // Request information from the user for each step.
            for (int i = 0; i < stepCount; i++)
            {
                string step;
                do
                {
                    Console.Write($"Enter step {i + 1}: ");
                    step = Console.ReadLine();

                    if (string.IsNullOrWhiteSpace(step))
                    {
                        Console.WriteLine("Step cannot be empty. Please enter a valid step.");
                    }
                } while (string.IsNullOrWhiteSpace(step)); // Keep asking until a step that isn't empty is entered.

                recipe.AddStep(i, step);
            }

            // Show a message of success and give back the generated recipe.
            Console.WriteLine("Recipe created successfully.");
            return recipe;
        }

        // Procedure to determine if a unit is permitted
        static bool IsUnitAllowed(string unit)
        {
            foreach (string allowedUnit in allowedUnits)
            {
                if (string.Equals(unit, allowedUnit, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        // Procedure to scale a recipe
        static void ScaleRecipe(List<Recipe> recipes)
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes to scale.");
                return;
            }

            Console.WriteLine("Choose a recipe to scale:");
            for (int i = 0; i < recipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipes[i].Name}");
            }

            int choice;
            if (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > recipes.Count)
            {
                Console.WriteLine("Invalid choice. Please enter a valid number.");
                return;
            }

            Recipe selectedRecipe = recipes[choice - 1];

            double factor;
            Console.Write("Enter scaling factor: ");
            if (!double.TryParse(Console.ReadLine(), out factor))
            {
                Console.WriteLine("Invalid scaling factor. Please enter a valid number.");
                return;
            }

            selectedRecipe.ScaleRecipe(factor);
        }

        // Procedure to reset ingredient quantities
        static void ResetQuantities(List<Recipe> recipes)
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes to reset quantities.");
                return;
            }

            Console.WriteLine("Choose a recipe to reset quantities:");
            for (int i = 0; i < recipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipes[i].Name}");
            }

            int choice;
            if (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > recipes.Count)
            {
                Console.WriteLine("Invalid choice. Please enter a valid number.");
                return;
            }

            Recipe selectedRecipe = recipes[choice - 1];
            selectedRecipe.ResetQuantities();
            Console.WriteLine("Ingredient quantities reset.");
        }

        // Method to remove a recipe from the list of recipes.
        static void ClearRecipe(List<Recipe> recipes)
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes to clear.");
                return;
            }

            Console.WriteLine("Choose a recipe to clear:");
            for (int i = 0; i < recipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipes[i].Name}");
            }

            int choice;
            if (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > recipes.Count)
            {
                Console.WriteLine("Invalid choice. Please enter a valid number.");
                return;
            }

            recipes.RemoveAt(choice - 1);
            Console.WriteLine("Recipe cleared.");
        }

        // Method to check if a string contains any numeric digits.
        static bool ContainsNumbers(string input)
        {
            return Regex.IsMatch(input, @"\d");
        }

        // Method to display a specific recipe and its details.
        static void DisplaySpecificRecipe(List<Recipe> recipes)
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes available.");
                return;
            }

            Console.WriteLine("Choose a recipe to display:");
            for (int i = 0; i < recipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipes[i].Name}");
            }

            int choice;
            if (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > recipes.Count)
            {
                Console.WriteLine("Invalid choice. Please enter a valid number.");
                return;
            }

            Recipe selectedRecipe = recipes[choice - 1];
            selectedRecipe.DisplayRecipe(); // Display the selected recipe details.

            // Calculate and display the total calories of the displayed recipe.
            double totalCalories = selectedRecipe.CalculateTotalCalories();
            Console.WriteLine($"Total Calories: {totalCalories}");

            // Check if total calories exceed 300 and notify the user if so
            if (totalCalories > 300)
            {
                Console.WriteLine("Warning: Total calories exceed 300!");   // Warn user if total calories exceed 300.
            }
        }
    }
}

