class Program
{
    static void Main(string[] args)
    {
        // Test Ingredient Class
        Ingredient ingredient = new Ingredient("Flour", 250, "grams", 400, "Grains");

        Console.WriteLine($"Ingredient: {ingredient.Name}, Quantity: {ingredient.Quantity} {ingredient.Unit}");
        Console.WriteLine($"Calories per Unit: {ingredient.Calories}, Food Group: {ingredient.FoodGroup}");

        // Test Recipe Class
        Recipe recipe = new Recipe("Chocolate Cake");

        recipe.AddIngredient(new Ingredient("Flour", 250, "grams", 400, "Grains"));
        recipe.AddIngredient(new Ingredient("Sugar", 150, "grams", 500, "Sweeteners"));

        recipe.AddStep("Preheat the oven to 180�C.");
        recipe.AddStep("Mix flour and sugar in a bowl.");
        recipe.AddStep("Bake for 30 minutes.");

        Console.WriteLine($"Recipe: {recipe.Name}");
        recipe.DisplayRecipe();

        Console.WriteLine($"Total Calories: {recipe.CalculateTotalCalories()}");

        recipe.ScaleRecipe(2);
        Console.WriteLine($"Scaled Recipe:");
        recipe.DisplayRecipe();

        recipe.ResetQuantities();
        Console.WriteLine($"Reset Quantities:");
        recipe.DisplayRecipe();

        Console.ReadLine();
    }
}
