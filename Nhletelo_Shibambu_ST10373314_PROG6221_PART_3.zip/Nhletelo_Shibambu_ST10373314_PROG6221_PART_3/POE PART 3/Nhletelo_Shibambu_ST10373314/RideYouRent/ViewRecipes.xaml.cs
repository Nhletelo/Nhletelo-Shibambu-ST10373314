﻿using RideYouRent.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;


namespace RideYouRent
{
    public partial class ViewRecipes : Page
    {
        private Dictionary<string, List<bool>> recipeStepCompletionStatus = new Dictionary<string, List<bool>>();
        private readonly string completionStatusFilePath = "recipe_completion_status.json"; // File path for storing completion statuses

        public ViewRecipes()
        {
            InitializeComponent();

            // Populate RecipeComboBox with recipe names (you might load this from StateManager or elsewhere)
            RecipeComboBox.ItemsSource = StateManager.recipes.Select(r => r.name).ToList();

            LoadCompletionStatus(); // Load saved completion status when page is initialized
        }

        private void RecipeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (RecipeComboBox.SelectedItem == null)
                return;

            string selectedRecipeName = RecipeComboBox.SelectedItem.ToString();

            // Assuming StateManager.recipes is a List<Recipe>
            Recipe selectedRecipe = StateManager.recipes
                .OrderBy(r => r.name) // Order the recipes alphabetically by name
                .FirstOrDefault(r => r.name == selectedRecipeName);

            if (selectedRecipe == null)
                return;

            StringBuilder recipeDetails = new StringBuilder();

            // Append basic recipe details
            recipeDetails.AppendLine($"Name: {selectedRecipe.name}");
            recipeDetails.AppendLine($"Description: {selectedRecipe.description}");
            recipeDetails.AppendLine();

            // Append ingredients details
            recipeDetails.AppendLine("Ingredients:");
            for (int i = 0; i < selectedRecipe.ingredients.Count; i++)
            {
                Ingredient ingredient = selectedRecipe.ingredients[i];
                recipeDetails.AppendLine($"\t{i + 1}. {ingredient.quantity} {ingredient.unitOfMesure} {ingredient.name}");
                recipeDetails.AppendLine($"\t   • Food Group: {ingredient.foodGroup}");
                recipeDetails.AppendLine($"\t   • Calories: {ingredient.calories}");
            }
            recipeDetails.AppendLine();

            // Calculate total calories and append calories details
            int totalCalories = selectedRecipe.ingredients.Sum(i => i.calories);
            recipeDetails.AppendLine($"Total Calories: {totalCalories}");
            recipeDetails.AppendLine();

            // Check if total calories exceed 300 and show alert if necessary
            if (totalCalories > 300)
            {
                MessageBox.Show($"Alert: Recipe '{selectedRecipe.name}' contains high total calories ({totalCalories}) that exceed 300.",
                    "Calorie Alert", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            // Append steps details
            recipeDetails.AppendLine("Steps:");
            List<StepViewModel> stepsViewModel = new List<StepViewModel>();
            List<bool> stepCompletionStatus = GetStepCompletionStatus(selectedRecipe.name); // Retrieve completion status from dictionary
            for (int i = 0; i < selectedRecipe.steps.Count; i++)
            {
                stepsViewModel.Add(new StepViewModel { StepText = selectedRecipe.steps[i], IsCompleted = stepCompletionStatus[i] });
                recipeDetails.AppendLine($"\t{i + 1}. {selectedRecipe.steps[i]}");
            }

            // Update RecipeDetailsTextBlock with the constructed details
            RecipeDetailsTextBlock.Text = recipeDetails.ToString();

            // Update StepsListBox with the steps view model
            StepsListBox.ItemsSource = stepsViewModel;
        }

        private void StepsListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Handle step completion logic
            ListBox listBox = sender as ListBox;
            if (listBox.SelectedItem != null)
            {
                StepViewModel selectedStep = listBox.SelectedItem as StepViewModel;
                selectedStep.IsCompleted = !selectedStep.IsCompleted; // Toggle completion status
                listBox.SelectedItems.Remove(selectedStep); // Clear selection for future toggling

                // Save the updated completion status
                SaveStepCompletionStatus();
            }
        }

        private List<bool> GetStepCompletionStatus(string recipeName)
        {
            // Retrieve step completion status for the given recipe name
            if (recipeStepCompletionStatus.ContainsKey(recipeName))
            {
                return recipeStepCompletionStatus[recipeName];
            }
            else
            {
                // If no status is saved yet, initialize with false (not completed)
                int stepsCount = StateManager.recipes.First(r => r.name == recipeName).steps.Count;
                List<bool> initialStatus = Enumerable.Repeat(false, stepsCount).ToList();
                recipeStepCompletionStatus.Add(recipeName, initialStatus);
                return initialStatus;
            }
        }

        private void SaveStepCompletionStatus()
        {
            // Save step completion status for the currently selected recipe
            if (RecipeComboBox.SelectedItem == null)
                return;

            string selectedRecipeName = RecipeComboBox.SelectedItem.ToString();
            List<bool> stepCompletionStatus = StepsListBox.Items.Cast<StepViewModel>().Select(step => step.IsCompleted).ToList();
            recipeStepCompletionStatus[selectedRecipeName] = stepCompletionStatus;

            SaveCompletionStatus(); // Save to file after updating in-memory dictionary
        }

        private void LoadCompletionStatus()
        {
            try
            {
                if (File.Exists(completionStatusFilePath))
                {
                    string json = File.ReadAllText(completionStatusFilePath);
                    recipeStepCompletionStatus = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, List<bool>>>(json);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading completion status: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SaveCompletionStatus()
        {
            try
            {
                string json = Newtonsoft.Json.JsonConvert.SerializeObject(recipeStepCompletionStatus, Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(completionStatusFilePath, json);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving completion status: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void HideButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeComboBox.SelectedItem != null)
            {
                HideButton.Visibility = Visibility.Visible;
                RecipeDetailsTextBlock.Visibility = Visibility.Visible;
                // Load and display the recipe details
                // For example:
                // RecipeDetailsTextBlock.Text = GetRecipeDetails(RecipeComboBox.SelectedItem);
            }
            else
            {
                HideButton.Visibility = Visibility.Collapsed;
                RecipeDetailsTextBlock.Visibility = Visibility.Collapsed;
            }
        }


        public class StepViewModel
        {
            public bool IsCompleted { get; set; }
            public string StepText { get; set; }
        }
    }
}
