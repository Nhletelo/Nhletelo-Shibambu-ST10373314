﻿using RideYouRent.Models;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace RideYouRent
{
    /// <summary>
    /// Interaction logic for ScaleRecipe.xaml
    /// </summary>
    public partial class ScaleRecipe : Page
    {
        // Dictionary for unit conversions
        private Dictionary<string, string> unitConversion = new Dictionary<string, string>()
        {
            { "teaspoon", "teaspoons" },
            { "tablespoon", "tablespoons" },
            { "cup", "cups" },
            { "pint", "pints" },
            { "quart", "quarts" },
            { "gallon", "gallons" },
            { "ounce", "ounces" },
            { "fluid ounce", "fluid ounces" },
            { "pound", "pounds" },
            { "milliliter", "milliliters" },
            { "liter", "liters" },
            { "gram", "grams" },
            { "kilogram", "kilograms" }
        };

        public ScaleRecipe()
        {
            InitializeComponent();
            PopulateCB();
        }

        /// <summary>
        /// Populates the combo box
        /// </summary>
        public void PopulateCB()
        {
            // Populate ComboBox
            SelectRecCB.ItemsSource = StateManager.recipes;
            SelectRecCB.DisplayMemberPath = "name";
        }

        /// <summary>
        /// Handles the scaling logic
        /// </summary>
        private void scaleRecipe_Click(object sender, RoutedEventArgs e)
        {
            // Gets recipe & scale factor
            Recipe selectedRecipe = (Recipe)SelectRecCB.SelectedItem;
            string scaleFactor = ScaeByCB.Text;

            switch (scaleFactor)
            {
                case "2x (Double)":
                    selectedRecipe.ScaleBy(2);
                    PrintRecipe(selectedRecipe);
                    break;
                case "3x (Triple)":
                    selectedRecipe.ScaleBy(3);
                    PrintRecipe(selectedRecipe);
                    break;
                case "4x (Quadruple)":
                    selectedRecipe.ScaleBy(4);
                    PrintRecipe(selectedRecipe);
                    break;
                default:
                    ErrorMessage.Content = "An error occurred - Please check Scale Factor";
                    break;
            }
        }

        /// <summary>
        /// Prints the recipe's details including ingredients and steps
        /// </summary>
        private void PrintRecipe(Recipe recipe)
        {
            RecipeTable.Children.Clear();

            // Recipe details
            Label details = new Label();
            details.Content = $"Recipe Details for {recipe.name}\n\t{recipe.description}";
            RecipeTable.Children.Add(details);

            // Steps
            Label stepsLabel = new Label();
            stepsLabel.Content = "Steps:";
            RecipeTable.Children.Add(stepsLabel);

            for (int i = 0; i < recipe.steps.Count; i++)
            {
                Label stepLabel = new Label();
                stepLabel.Content = $"{i + 1}. {recipe.steps[i]}";
                RecipeTable.Children.Add(stepLabel);
            }

            // Ingredients
            Label ingredientsHeader = new Label();
            ingredientsHeader.Content = "Ingredients:";
            RecipeTable.Children.Add(ingredientsHeader);

            for (int i = 0; i < recipe.ingredients.Count; i++)
            {
                var ingredient = recipe.ingredients[i];
                Label ingredientLabel = new Label();
                string convertedUnit = unitConversion.ContainsKey(ingredient.unitOfMesure.ToLower())
                                        ? unitConversion[ingredient.unitOfMesure.ToLower()]
                                        : ingredient.unitOfMesure;
                ingredientLabel.Content = $"{i + 1}. {ingredient.name} {ingredient.quantity} {convertedUnit}";
                RecipeTable.Children.Add(ingredientLabel);
            }
        }

        /// <summary>
        /// Handles resetting logic
        /// </summary>
        private void resetQuant_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Recipe selectedRecipe = (Recipe)SelectRecCB.SelectedItem;
                selectedRecipe.ResetQuantities();
                PrintRecipe(selectedRecipe);
            }
            catch
            {
                ErrorMessage.Content = "An error occurred with resetting values.";
            }
        }
    }
}
