﻿using RideYouRent.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RideYouRent
{
    /// <summary>
    /// Interaction logic for CreateRecipe.xaml
    /// </summary>
    public partial class CreateRecipe : Page
    {
        public Recipe recipe;
        public CreateRecipe()
        {
            InitializeComponent();
            recipe = new Recipe();
        }

        /// <summary>
        /// Adds an Ingredient to list
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            ErrorMessage.Content = "";
            try
            {
                // Collecting Data from user
                string name = TB_IngridentName.Text;
                int quantity = Convert.ToInt32(TB_Quantity.Text);
                string measure = CB_UnitOfMeasure.Text;
                int calories = Convert.ToInt32(TB_Calories.Text);
                string foodGroup = CB_FoodGroup.Text;

                // Check if calories exceed 300
                if (calories > 300)
                {
                    MessageBox.Show($"Alert: Calories ({calories}) exceed 300!", "Calorie Alert", MessageBoxButton.OK, MessageBoxImage.Warning);
                }

                // Creating recipe
                recipe.ingredients.Add(new Ingredient(name, quantity, measure, calories, foodGroup));
                PopulateTable();
                ResetIngredient();

            }
            catch (FormatException)
            {
                ErrorMessage.Content = "Calories must be a valid integer.";
            }
            catch (Exception ex)
            {
                ErrorMessage.Content = $"An Error Occured - {ex.Message}";
            }
        }


        /// <summary>
        /// Adding Step button action hander
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddStep_Click(object sender, RoutedEventArgs e)
        {
            ErrorMessage.Content = "";
            try
            {
                // Adds to Steps, and reset's textbox
                recipe.steps.Add(TB_StepDesc.Text);
                PopulateTable();
                TB_StepDesc.Text = "";
            }
            catch
            {
                ErrorMessage.Content = "An Error Occured - Please ensure inputted Step is correct";
            }
        }

        /// <summary>
        /// Adding Recipe button handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            ErrorMessage.Content = "";
            try
            {
                string name = TB_Name.Text;
                string desc = TB_Dresc.Text;

                recipe.AddDetails(name, desc);

                // Ensuring there are Ingredient's and Steps in the recipe
                if (recipe.ingredients.Count > 0 || recipe.steps.Count > 0)
                {
                    StateManager.recipes.Add(recipe);
                    SuccessMessage.Content = "Recipe Successfuly Added!";

                    // Reseting UI for next add
                    ResetRec();
                    ResetIngredient();
                    InputTable.Children.Clear();
                    recipe = new Recipe();
                    return;
                }

                ErrorMessage.Content = "Please Add A Step & Ingredient to Continue";
            }
            catch
            {
                ErrorMessage.Content = "An Error Occured - Please ensure inputted Recipe is correct";
            }
        }


        public void PopulateTable()
        {
            // Clearing UI
            ErrorMessage.Content = "";
            InputTable.Children.Clear();

            // Only show list if Ingredients is presenet, same for next If statement
            if (recipe.ingredients.Count > 0)
            {
                // Creates a Label for liest
                Label ingreHeader = new Label();
                ingreHeader.Content = "Ingredients Added";
                InputTable.Children.Add(ingreHeader);

                // Looping of Ingredients and adding to table 
                for (int i = 0; i < recipe.ingredients.Count; i++)
                {
                    Label value = new Label();

                    value.Content = $"{i + 1} - {recipe.ingredients[i].name} {recipe.ingredients[i].quantity}{recipe.ingredients[i].unitOfMesure} ";
                    InputTable.Children.Add(value);
                }
            }

            // Same process as above - but for Steps
            if (recipe.steps.Count > 0)
            {
                Label stepsHeader = new Label();
                stepsHeader.Content = "Steps Added";
                InputTable.Children.Add(stepsHeader);

                for (int i = 0; i < recipe.steps.Count; i++)
                {
                    Label value = new Label();

                    value.Content = $"{i + 1} - {recipe.steps[i]}";
                    InputTable.Children.Add(value);
                }
            }
        }


        /// <summary>
        /// Handles the Resting of UI for Receipe
        /// </summary>
        private void ResetRec()
        {
            TB_Name.Text = "";
            TB_Dresc.Text = "";
            TB_StepDesc.Text = "";
        }
        /// <summary>
        /// Handles the reseting of UI for Ingredients
        /// </summary>
        private void ResetIngredient()
        {
            TB_IngridentName.Text = "";
            TB_Quantity.Text = "";
            CB_UnitOfMeasure.Text = "";
            TB_Calories.Text = "";
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            // Hide the current page
            this.Visibility = Visibility.Hidden;
        }

        private void CB_UnitOfMeasure_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateUnitOfMeasure();
        }

        private void TB_Quantity_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateUnitOfMeasure();
        }

        private void UpdateUnitOfMeasure()
        {
            if (CB_UnitOfMeasure.SelectedItem != null && int.TryParse(TB_Quantity.Text, out int quantity))
            {
                ComboBoxItem selectedItem = CB_UnitOfMeasure.SelectedItem as ComboBoxItem;
                if (selectedItem != null)
                {
                    string unit = selectedItem.Content.ToString();
                    if (quantity > 1)
                    {
                        // Handle plural forms
                        if (unit == "teaspoon") unit = "teaspoons";
                        else if (unit == "tablespoon") unit = "tablespoons";
                        else if (unit == "cup") unit = "cups";
                        else if (unit == "pint") unit = "pints";
                        else if (unit == "quart") unit = "quarts";
                        else if (unit == "gallon") unit = "gallons";
                        else if (unit == "ounce") unit = "ounces";
                        else if (unit == "fluid ounce") unit = "fluid ounces";
                        else if (unit == "pound") unit = "pounds";
                        else if (unit == "milliliter") unit = "milliliters";
                        else if (unit == "liter") unit = "liters";
                        else if (unit == "gram") unit = "grams";
                        else if (unit == "kilogram") unit = "kilograms";
                    }
                    // Set the content of the selected ComboBoxItem to the plural form if needed
                    selectedItem.Content = unit;
                }
            }
        }
    }
}