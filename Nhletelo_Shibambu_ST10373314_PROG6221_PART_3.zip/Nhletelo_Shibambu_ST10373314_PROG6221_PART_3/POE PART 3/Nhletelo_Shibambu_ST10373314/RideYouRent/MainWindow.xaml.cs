﻿using RideYouRent.Models;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace RideYouRent
{
    public partial class MainWindow : Window
    {
        private Recipe selectedRecipe; // Assuming you have logic to set this when a recipe is selected

        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            NavigateToPage(new CreateRecipe());
        }

        private void DisplayRecipe_Click(object sender, RoutedEventArgs e)
        {
            // Check if there are recipes available
            if (StateManager.recipes.Count == 0)
            {
                // Show alert message
                MessageBox.Show("There are no recipes available to display.", "No Recipes", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                // Navigate to the ViewRecipes page
                NavigateToPage(new ViewRecipes());
            }
        }


        private void ScaleRecipe_Click(object sender, RoutedEventArgs e)
        {
            // Check if there are recipes available
            if (StateManager.recipes.Count == 0)
            {
                // Show alert message
                MessageBox.Show("There are no recipes available to scale.", "No Recipes", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                // Navigate to the ScaleRecipe page
                NavigateToPage(new ScaleRecipe());
            }
        }


        private void PieChart_Click(object sender, RoutedEventArgs e)
        {
            // Check if there are recipes available
            if (StateManager.recipes.Count == 0)
            {
                // Show alert message
                MessageBox.Show("There are no recipes available to display in a pie chart.", "No Recipes", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                // Navigate to the pie chart page
                NavigateToPage(new PieChart());
            }
        }


        private void DeleteRecipe_Click(object sender, RoutedEventArgs e)
        {
            // Check if there are recipes available to delete
            if (StateManager.recipes.Count == 0)
            {
                MessageBox.Show("There are no recipes available to delete.", "No Recipes", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                // Call method to navigate to the delete recipe page
                NavigateToPage(new DeleteRecipe());
            }
        }


        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            // Display confirmation message box
            MessageBoxResult result = MessageBox.Show("Are you sure you want to exit?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);

            // Check user's choice
            if (result == MessageBoxResult.Yes)
            {
                // Dispose disposable content if MainFrame's content implements IDisposable
                if (MainFrame.Content is IDisposable disposableContent)
                {
                    disposableContent.Dispose();
                }

                // Shutdown the application
                Application.Current.Shutdown();
            }
        }


        private void NavigateToPage(Page page)
        {
            try
            {
                if (MainFrame.NavigationService != null)
                {
                    MainFrame.NavigationService.Navigate(page);
                }
                else
                {
                    MessageBox.Show("Navigation service is not available.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void MainFrame_Navigated_1(object sender, NavigationEventArgs e)
        {
            // Optionally handle navigation events if needed
        }
    }
}
